
package poo.ejerciciopropuesto22g;

public class EjercicioPropuesto22g {

    public static void main(String[] args) {
        PantallaEmpresaCuentas ventana = new PantallaEmpresaCuentas();
        ventana.show(true);
    }
}
