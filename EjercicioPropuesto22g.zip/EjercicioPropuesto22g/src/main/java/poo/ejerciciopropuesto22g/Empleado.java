
package poo.ejerciciopropuesto22g;

public class Empleado {
    
    String nombre, apellido;
    double salarioHora, horasMes;
    
    Empleado(String nombre, String apellido, double salarioHora, double horasMes){
        this.nombre = nombre;
        this.apellido = apellido;
        this.salarioHora = salarioHora;
        this.horasMes = horasMes;
    }
    
    String salarioMensual(){
        double salarioMes = salarioHora*horasMes;
        if((salarioMes)>450000){
            return nombre+" "+apellido+" su salario mensual es de "+salarioMes;
        }else{
            return nombre+" "+apellido;
        }
    }
}
