
package poo.ejercicioresuelto7;

class EjercicioResuelto7 {

    public static void main(String[] args) {
        PantallaDiferenciasNumeros ventana = new PantallaDiferenciasNumeros();
        ventana.show(true);
    }
}
