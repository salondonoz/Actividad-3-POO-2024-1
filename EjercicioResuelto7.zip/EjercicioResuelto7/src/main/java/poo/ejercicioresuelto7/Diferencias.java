
package poo.ejercicioresuelto7;


public class Diferencias {
    double a,b;
    
    Diferencias(double a, double b){
        this.a =a;
        this.b=b;
    }
    
    String comparar(){
        if(a>b){
            return a+" Es mayor que "+b;
        } else if(a<b) {
            return a+" Es menor que "+b;
        } else {
            return a+" Es igual a "+b;
        }
    }
}
