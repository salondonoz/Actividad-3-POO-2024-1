
package poo.ejerciciopropuesto23g;


public class EjercicioPropuesto23g {

    public static void main(String[] args) {
        PantallaSolucionEcuacion ventana = new PantallaSolucionEcuacion();
        ventana.show(true);
    }
}
