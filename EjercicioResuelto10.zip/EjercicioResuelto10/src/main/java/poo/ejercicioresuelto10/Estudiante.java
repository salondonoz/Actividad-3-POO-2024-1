
package poo.ejercicioresuelto10;

public class Estudiante {
    int NI, estrato;
    String nombres;
    double patrimonio;
    
    Estudiante(int NI, String nombres, double patrimonio, int estrato){
        this.NI = NI;
        this.nombres = nombres;
        this.patrimonio = patrimonio;
        this.estrato = estrato;
    }
    
    double pagoMatricula(){
        if((patrimonio > 2000000) && (estrato>3)){
            return 50000 + (0.003*patrimonio);
        } else{
            return 50000;
        }
    }
    
}
