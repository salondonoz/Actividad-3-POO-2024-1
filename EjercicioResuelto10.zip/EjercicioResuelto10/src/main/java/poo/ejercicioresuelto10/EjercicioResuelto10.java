
package poo.ejercicioresuelto10;

public class EjercicioResuelto10 {

    public static void main(String[] args) {
        PantallaUniversidad ventana = new PantallaUniversidad();
        ventana.show(true);
        
    }
}
