
package poo.ejerciciopropuesto19;

public class EjercicioPropuesto19 {

    public static void main(String[] args) {
        PantallaTriangulo ventana = new PantallaTriangulo();
        ventana.show(true);
    }
}
