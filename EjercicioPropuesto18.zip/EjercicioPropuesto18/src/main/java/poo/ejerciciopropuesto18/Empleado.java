
package poo.ejerciciopropuesto18;

public class Empleado {
    int documento;
    double numHoras, valorHora, prctRet;
    String nombre, apellido;
    
    Empleado(int documento,String nombre, String apellido, double numHoras, double valorHora, double prctRet){
        this.documento = documento;
        this.nombre = nombre;
        this.apellido = apellido;
        this.numHoras = numHoras;
        this.valorHora = valorHora;
        this.prctRet = prctRet;
    }
    
    double salarioBruto(){
        return numHoras*valorHora;
    }
    
    double salarioNeto(){
        return salarioBruto()*((100-prctRet) / 100);
    }
    
}
