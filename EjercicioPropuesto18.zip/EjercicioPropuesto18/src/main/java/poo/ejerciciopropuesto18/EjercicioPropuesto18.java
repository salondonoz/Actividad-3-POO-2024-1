
package poo.ejerciciopropuesto18;


public class EjercicioPropuesto18 {

    public static void main(String[] args) {
        
    PantallaEmpresa ventana = new PantallaEmpresa();
    ventana.show(true);
        
        
    }
}
