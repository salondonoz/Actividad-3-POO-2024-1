
package poo.pruebafiguras;

public class Rombo {
    int diagonal1, diagonal2;
    
    /**
    * Constructor de la clase Rombo
    */
    Rombo(int diagonal1, int diagonal2) {
    this.diagonal1 = diagonal1;
    this.diagonal2 = diagonal2;
    }
    /**
    * Método que calcula y devuelve el área de un rombo como la
    * multiplicación de las dos diagonales divididad por dos
    * @return Área de un rombo
    */
    double calcularArea() {
    return (diagonal1 * diagonal2) / 2;
    }
 
    /**
    * Método que calcula y devuelve el perímetro de un rombo
    * como el lado 4 veces
    * @return Perímetro de un rombo
    */
    double calcularPerimetro() {
        return 2 * Math.pow(diagonal1*diagonal1 + diagonal2*diagonal2, 0.5) ;
    }
}
