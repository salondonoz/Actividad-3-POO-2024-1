
package poo.pruebafiguras;

public class Trapecio {
    int base1, base2, altura;
    
    /**
    * Constructor de la clase Rombo
    */
    Trapecio(int base1, int base2, int altura) {
    this.base1 = base1;
    this.base2 = base2;
    this.altura = altura;
    }
    /**
    * Método que calcula y devuelve el área de un trapecio como la
    * suma de las dos bases divididas por dos y multiplicadas por la altura
    * @return Área de un trapecio
    */
    double calcularArea() {
    return ((base1 + base2) / 2) * altura;
    }
    /**
    * Método que calcula y devuelve el perímetro de un trapecio
    * @return Perímetro de un rectángulo
    */
    double calcularLado() {
    if (base1 < base2)     
        return Math.pow(((base2 - base1)/2)*((base2 - base1)/2) + altura*altura, 0.5);
    else 
        return Math.pow(((base1 - base2)/2)*((base1 - base2)/2) + altura*altura, 0.5);    
    }
    double calcularPerimetro() {
    return base1 + base2 + (calcularLado()*2) ;
    }
    
}
